---
name: skill-forjaERP-EmitirCotizacion-v1
description: "Trigger: cotizar, cotización, proforma, presupuesto, emitir cotización, reemitir, corregir o duplicar una cotización de Cia. ESTRUMETAL S.A.C. Genera el PDF oficial estampando los datos sobre la plantilla corporativa. Parte del sistema forjaERP: corre sin usuario y jamás hace preguntas."
license: Apache-2.0
metadata:
  author: gentleman-programming
  version: "1.0"
  system: forjaERP
---

## Contexto de sistema (forjaERP)

Esta skill es un componente del **sistema forjaERP**. Corre de forma
**desatendida (headless)**: no hay usuario que responda. Por lo tanto:

- **JAMÁS hagas preguntas ni esperes confirmación.** Toda decisión tiene un
  valor por defecto documentado en esta skill; aplicalo y seguí.
- No abortes por falta de un dato opcional: usá el default y seguí.
- El "corte" de una cotización con más de 16 ítems se decide solo, siguiendo
  el protocolo de `references/datos.md` §4, y se reporta en el resultado.
- Si un requisito no puede cumplirse (plantilla ausente, dependencia faltante),
  fallá con un mensaje de error claro y accionable; no inventes salida.

## Activation Contract

Activa esta skill para cotizar, reemitir, corregir o duplicar cotizaciones de
Cia. ESTRUMETAL S.A.C. No la actives para tareas ajenas a la cotización
(facturación, inventario, compras).

## Hard Rules

- No edites `scripts/cotizador.py` salvo que una regla de esta skill lo pida
  explícitamente. El script es la fuente de verdad de geometría y aritmética.
- El JSON de datos **siempre se escribe y se lee en cp1252** (la codepage del
  sistema donde corre el script): `open(p, 'w', encoding='cp1252')` al escribir
  y `encoding='cp1252'` al releer. Un JSON en UTF-8 corrompe la Ñ y los
  acentos en el PDF renderizado.
- Nunca asumas que un texto largo "entró": el script **recorta en silencio**
  el detalle de cada ítem. Revisá siempre el render (paso 4).
- Antes de emitir, verificá que el correlativo no exista ya en el directorio de
  salida (`ls | grep <correlativo>`). Si está usado, elegí el siguiente número
  libre y anotalo en el reporte. No preguntes.
- Si el PDF destino está bloqueado (abierto en un visor → `PermissionError`),
  emití como `<nombre base> v2.pdf` y anotalo en el reporte. No preguntes.
- No registres nada en ninguna base de datos externa: esta skill solo emite el
  PDF. La persistencia es responsabilidad de otra pieza del sistema.
- Si la emisión falla, escribí el **archivo de error** según el contrato de
  `references/errores.md` (tipo numérico + mensaje corto para el usuario +
  detalle técnico para nosotros) y terminá. No reintentos ni preguntas.

## Decision Gates

| Situación | Acción (sin preguntar) |
|---|---|
| Pedido de cotizar / presupuestar / proforma | Activar esta skill y seguir el flujo. |
| Más de 16 ítems en modo tabla | Aplicar el protocolo de división por familia (§4 de referencias) automáticamente y reportar el corte en el resultado. |
| Ítem con detalle de 2+ líneas y la cotización tiene 10+ ítems | Usar 1 línea de detalle y revisar el render ítem por ítem. |
| Número de cotización ya usado | Elegir el siguiente libre y anotarlo en el reporte. |
| PDF destino bloqueado | Emitir `v2` y anotarlo en el reporte. |

## Execution Steps

1. **Reúne los datos.** Número, fecha, cliente, concepto e ítems (cantidad,
   precio unitario, descripción). Dirección/atencion opcionales. Defaults:
   `lugar` "Villa El Salvador", `forma_pago` "contado", `validez_dias` 15,
   `mostrar_igv` true. Fecha por defecto: hoy.
2. **Escribe el JSON de datos en cp1252.** Estructura completa en
   `references/datos.md`.
3. **Ejecuta el generador.**
   ```bash
   python scripts/cotizador.py datos.json "Cotizacion 184-2026 - Cliente.pdf"
   ```
   Imprime `total`, `igv` y `con igv`; verificá que cuadren antes de entregar.
4. **Revisá el PDF visualmente ítem por ítem** (render a PNG con pymupdf o
   `pdftoppm`). Mirá cada ítem con detalle: el script no avisa si una línea
   del detalle se cayó.
5. **Entrega el PDF.** Sin registro en ninguna base externa.

Requisitos: `pypdf` y `reportlab`. Si faltan:
`pip install pypdf reportlab`

## Output Contract

Devolve:
- Archivo(s) de salida PDF generado(s) con su ruta.
- Totales verificados (`total`, `igv`, `con igv`).
- Si hubo división por >16 ítems: partes generadas y corte aplicado.
- Si se eligió un correlativo distinto al pedido, o se emitió como `v2`:
  anotarlo explícitamente.
- Cualquier detalle recortado o ambigüedad de los datos de entrada.

## References

- `references/datos.md` — estructura JSON completa, coordenadas de la
  plantilla, división por >16 ítems, condiciones comerciales y bugs conocidos.
- `references/errores.md` — contrato de errores: archivo JSON que la skill
  deja cuando falla, tipos numerados y mensaje corto que el programa anfitrión
  de forjaERP muestra al usuario.
- `assets/plantilla.pdf` — membrete corporativo oficial (página 1 en blanco).

## Dependencia hermana

La skill `cotizador-extraer` (proyecto Estrumetal) convierte documentos de
cotización existentes (PDF/XLSX/imagen) al JSON que esta skill consume. Esta
skill SOLO emite.
