"""
Generador de cotizaciones Cia. ESTRUMETAL S.A.C.
Estampa los datos sobre la plantilla en blanco (assets/plantilla.pdf), asi el
diseno, el logo, los iconos y el pie quedan identicos al original.

Uso:  python3 cotizador.py datos.json salida.pdf
Para usar otra plantilla:  ESTRUMETAL_PLANTILLA=/ruta/otra.pdf python3 cotizador.py ...
"""
import io
import json
import os
import sys
from datetime import date

from pypdf import PdfReader, PdfWriter
from reportlab.lib.colors import Color, HexColor
from reportlab.pdfbase.pdfmetrics import stringWidth
from reportlab.pdfgen import canvas

_AQUI = os.path.dirname(os.path.abspath(__file__))
PLANTILLA = os.environ.get(
    "ESTRUMETAL_PLANTILLA",
    os.path.normpath(os.path.join(_AQUI, "..", "assets", "plantilla.pdf")))
W, H = 768.0, 1152.0
OFFSET = 7.919956   # origen del MediaBox de la plantilla

NAVY = HexColor("#001F55")
NEGRO = HexColor("#231F20")
GRIS = HexColor("#3C3C3C")
LINEA = HexColor("#8C8C8C")

# columnas de la tabla (x en px desde la izquierda, medidos del original)
CX = [40, 102, 454, 587, 710]
TABLA_Y0 = 468          # arriba del encabezado de la tabla
ENCABEZADO_H = 21
FILA_MIN = 56
TOTALES_H = 21
TABLA_Y_MAX = 900       # deja aire antes de la barra de condiciones

MESES = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio",
         "Agosto", "Setiembre", "Octubre", "Noviembre", "Diciembre"]

CONDICIONES = {
    "contado": "Forma de Pago: Al contado.",
    "credito30": "Forma de Pago: Cr\u00e9dito a 30 d\u00edas.",
    "50_50": "Forma de Pago: Adelanto 50% y el otro 50% contraentrega.",
}

PIE = {
    "razon_social": "Cia. Estrumetal S.a.c. | Estrumetal",
    "ruc": "20555485019",
    "atencion": "Atenci\u00f3n lunes - S\u00e1bados",
    "direccion1": "Av. Pedro Huilca - Parcela 1 Mz. G Lote 7",
    "direccion2": "Parque Industrial - Villa El Salvador - Lima - Per\u00fa",
    "web": "www.ciaestrumetal.com",
    "telefono": "987 966 497",
    "correo": "ventas@ciaestrumetal.com",
}


def y(px):
    """Convierte y desde el borde superior visible a coordenada PDF de la plantilla."""
    return H + OFFSET - px


def soles(v):
    return "S/. {:,.2f}".format(v)


def fecha_larga(iso):
    d = date.fromisoformat(iso)
    return "{} de {} de {}".format(d.day, MESES[d.month - 1], d.year)


def texto(c, x, py, s, font="Helvetica", size=9, color=NEGRO):
    c.setFont(font, size)
    c.setFillColor(color)
    c.drawString(x, y(py), s)


def centrado(c, x0, x1, py, s, font="Helvetica", size=9, color=NEGRO):
    c.setFont(font, size)
    c.setFillColor(color)
    c.drawCentredString((x0 + x1) / 2.0, y(py), s)


def encoge(s, font, size, ancho):
    """Reduce el tamano de fuente hasta que el texto entre en el ancho dado."""
    while size > 5.0 and stringWidth(s, font, size) > ancho:
        size -= 0.25
    return size


def envolver(s, font, size, ancho):
    palabras, lineas, cur = s.split(), [], ""
    for p in palabras:
        prueba = (cur + " " + p).strip()
        if stringWidth(prueba, font, size) <= ancho:
            cur = prueba
        else:
            if cur:
                lineas.append(cur)
            cur = p
    if cur:
        lineas.append(cur)
    return lineas


def cuerpo_texto(c, d):
    """Modo descriptivo: en vez de tabla de items, un bloque de texto y un total."""
    y0, y1 = 476.0, 938.0
    lineas = d.get("cuerpo", [])
    resumen = d.get("resumen", [])
    tiene_total = d.get("total") is not None

    alto_extra = (len(resumen) * 14) + (50 if tiene_total else 0)
    size = 9.5   # arranca grande y solo baja si el contenido no entra
    while size > 5.5 and (len(lineas) * (size + 1.6) + alto_extra) > (y1 - y0):
        size -= 0.1
    paso = size + 1.6

    py = y0 + size
    for ln in lineas:
        if isinstance(ln, str):
            ln = {"t": ln}
        txt = ln.get("t", "")
        if txt:
            font = "Helvetica-Bold" if ln.get("b") else "Helvetica"
            color = NAVY if ln.get("c") == "navy" else NEGRO
            x = CX[0] + 6 + (ln.get("i", 0) * 10)
            tam = encoge(txt, font, size, CX[-1] - x - 10)
            texto(c, x, py, txt, font=font, size=tam, color=color)
            if ln.get("u"):
                c.setStrokeColor(color)
                c.setLineWidth(0.4)
                c.line(x, y(py + 1.6), x + stringWidth(txt, font, tam), y(py + 1.6))
        py += paso

    if resumen:
        py += 6
        for etiqueta, valor in resumen:
            texto(c, CX[2] - 40, py, etiqueta, font="Helvetica-Bold", size=size + 0.6, color=NAVY)
            texto(c, CX[3] + 8, py, valor, font="Helvetica-Bold", size=size + 0.6, color=NAVY)
            py += paso + 2.5

    if tiene_total:
        py += 10
        alto = 22
        c.setStrokeColor(NEGRO)
        c.setLineWidth(0.9)
        c.rect(CX[0], y(py + alto - 8), CX[-1] - CX[0], alto, stroke=1, fill=0)
        centrado(c, CX[0], CX[-1], py + 6, "{} S/. {:,.2f}".format(
            d.get("total_label", "IMPORTE TOTAL:"), d["total"]),
            font="Helvetica-Bold", size=11.5, color=NAVY)
        py += alto + 6
    return py


def construir(d, salida):
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(W, H + OFFSET))

    # ---------- tapar residuos de la plantilla ----------
    c.setFillColor(HexColor("#F7F7F7"))
    for x0, py0, x1, py1 in ((433, 195, 748, 216), (435, 244, 745, 275), (44, 1076, 360, 1093)):
        c.rect(x0, y(py1), x1 - x0, py1 - py0, stroke=0, fill=1)

    # ---------- lugar, fecha y numero ----------
    texto(c, 439, 207, "{}, {}".format(d.get("lugar", "Villa El Salvador"),
                                       fecha_larga(d["fecha"])), size=11, color=NEGRO)
    num = "COTIZACI\u00d3N N\u00b0 {}".format(d["numero"])
    texto(c, 439, 268, num, font="Helvetica-Bold",
          size=encoge(num, "Helvetica-Bold", 23.5, 300), color=NAVY)

    # ---------- datos del cliente ----------
    texto(c, 47, 325, "Se\u00f1ores:", font="Helvetica-Bold", size=8.8)
    texto(c, 47, 341, d["cliente"]["nombre"], font="Helvetica-Bold",
          size=encoge(d["cliente"]["nombre"], "Helvetica-Bold", 11.5, 360))
    if d["cliente"].get("direccion"):
        texto(c, 47, 360, "Direcci\u00f3n:", font="Helvetica-Bold", size=8.8)
        texto(c, 47, 375, d["cliente"]["direccion"],
              size=encoge(d["cliente"]["direccion"], "Helvetica", 10.8, 370), color=NEGRO)
    if d["cliente"].get("atencion"):
        texto(c, 47, 395, "Atenci\u00f3n:", font="Helvetica-Bold", size=8.8)
        texto(c, 47, 410, d["cliente"]["atencion"],
              size=encoge(d["cliente"]["atencion"], "Helvetica", 10.8, 370), color=NEGRO)

    # ---------- concepto ----------
    texto(c, 47, 443, "Mediante la presente le hacemos llegar la cotizaci\u00f3n solicitada por:",
          size=10.2, color=NEGRO)
    texto(c, 47, 458, d["concepto"], font="Helvetica-Bold",
          size=encoge(d["concepto"], "Helvetica-Bold", 11, 380))

    # ---------- cuerpo: tabla de items o bloque descriptivo ----------
    total, igv = 0.0, 0.0
    if d.get("cuerpo"):
        cuerpo_texto(c, d)
        total = d.get("total", 0.0)
    else:
        # ---------- tabla ----------
        items = d["items"]
        n = len(items)
        disponible = TABLA_Y_MAX - (TABLA_Y0 + ENCABEZADO_H)
        fila_h = min(66.0, disponible / max(n, 1))
        if fila_h < 26.0:
            raise SystemExit(
                "No entran {} items en una pagina del diseno. Maximo 16 por cotizacion.".format(n))
        det_size = 7.8 if fila_h >= 45 else 7.0
        max_lineas = max(1, int((fila_h - 11.0) / (det_size + 1.8)))

        # encabezado
        c.setFillColor(NAVY)
        c.rect(CX[0], y(TABLA_Y0 + ENCABEZADO_H), CX[-1] - CX[0], ENCABEZADO_H,
               stroke=0, fill=1)
        for i, t in enumerate(["CANT.", "DESCRIPCI\u00d3N", "PRECIO UNIT.", "IMPORTE TOTAL"]):
            centrado(c, CX[i], CX[i + 1], TABLA_Y0 + 15, t,
                     font="Helvetica-Bold", size=8.5, color=HexColor("#FFFFFF"))

        c.setLineWidth(0.7)
        c.setStrokeColor(LINEA)
        cur = TABLA_Y0 + ENCABEZADO_H
        total = 0.0
        for it in items:
            importe = it["cantidad"] * it["precio"]
            total += importe
            alto = fila_h
            # bordes
            c.rect(CX[0], y(cur + alto), CX[-1] - CX[0], alto, stroke=1, fill=0)
            for x in CX[1:-1]:
                c.line(x, y(cur), x, y(cur + alto))
            centro = cur + alto / 2.0
            centrado(c, CX[0], CX[1], centro + 3, "{:,.0f}".format(it["cantidad"]), size=9.5)
            centrado(c, CX[2], CX[3], centro + 3, soles(it["precio"]), size=9.5)
            centrado(c, CX[3], CX[4], centro + 3, soles(importe), size=9.5)

            ancho_desc = CX[2] - CX[1] - 16
            nombre_size = encoge(it["nombre"], "Helvetica-Bold", 8.5, ancho_desc)
            lineas = []
            for linea in it.get("detalle", []):
                lineas.extend(envolver(linea, "Helvetica", det_size, ancho_desc))
            lineas = lineas[:max_lineas]
            paso_det = det_size + 1.8
            alto_bloque = 11 + len(lineas) * paso_det
            py = cur + (alto - alto_bloque) / 2.0 + 9
            texto(c, CX[1] + 8, py, it["nombre"], font="Helvetica-Bold", size=nombre_size)
            for linea in lineas:
                py += paso_det
                texto(c, CX[1] + 8, py, linea, size=det_size, color=GRIS)
            cur += alto

        # ---------- totales ----------
        if d.get("mostrar_igv", True):
            igv = total * d.get("igv", 0.18)
            filas = (("TOTAL:", total), ("CON IGV:", total + igv))
        else:
            igv = 0.0
            filas = (("IMPORTE TOTAL:", total),)
        for etiqueta, valor in filas:
            c.rect(CX[0], y(cur + TOTALES_H), CX[-1] - CX[0], TOTALES_H, stroke=1, fill=0)
            c.line(CX[3], y(cur), CX[3], y(cur + TOTALES_H))
            centrado(c, CX[0], CX[3], cur + 14, etiqueta, font="Helvetica-Bold", size=9.5)
            centrado(c, CX[3], CX[4], cur + 14, soles(valor), font="Helvetica-Bold", size=9.5)
            cur += TOTALES_H

    # ---------- condiciones comerciales ----------
    if d.get("condiciones"):
        bullets = list(d["condiciones"])
    else:
        pago = d.get("texto_pago") or CONDICIONES[d["forma_pago"]]
        bullets = [
            "Los Precios son expresados en Nuevos Soles",
            "Los precios no incluyen el IGV",
            pago,
            "Validez de Cotizaci\u00f3n: {} d\u00edas. Despu\u00e9s de ese plazo, precios sujetos "
            "a variaci\u00f3n del acero.".format(d["validez_dias"]),
        ] + d.get("condiciones_extra", [])

    n_b = len(bullets)
    paso = min(11.3, (1046.0 - 989.0) / max(n_b - 1, 1))
    if n_b > 9:
        raise SystemExit("Maximo 9 condiciones comerciales por cotizacion.")
    tam = max(6.5, min(7.8, paso * 0.80))
    py = 989.0
    for b in bullets:
        c.setFillColor(NEGRO)
        c.circle(50, y(py) + tam * 0.33, 1.4, stroke=0, fill=1)
        texto(c, 56, py, b, size=encoge(b, "Helvetica", tam, 344), color=NEGRO)
        py += paso

    # ---------- cierre ----------
    texto(c, 47, 1088, d.get("cierre",
          "A la espera de su pronta comunicaci\u00f3n quedamos a su servicio."),
          size=8, color=NEGRO)

    # ---------- pie ----------
    texto(c, 12, 1130, "Raz\u00f3n Social", font="Helvetica-Bold", size=6.3)
    texto(c, 12 + stringWidth("Raz\u00f3n Social", "Helvetica-Bold", 6.3) + 3, 1130,
          PIE["razon_social"], size=6.3)
    texto(c, 174, 1124, "RUC", font="Helvetica-Bold", size=6.0, color=NAVY)
    texto(c, 174, 1133, PIE["ruc"], size=6.6)
    texto(c, 253, 1128, PIE["atencion"], size=5.8)
    texto(c, 356, 1124, PIE["direccion1"], size=5.65)
    texto(c, 356, 1133, PIE["direccion2"], size=5.6)
    texto(c, 516, 1128, PIE["web"], size=5.85)
    texto(c, 612, 1128, PIE["telefono"], size=5.75)
    texto(c, 679, 1128, PIE["correo"], size=6.25)

    c.showPage()
    c.save()
    buf.seek(0)

    plantilla = PdfReader(PLANTILLA).pages[0]
    plantilla.merge_page(PdfReader(buf).pages[0])
    w = PdfWriter()
    w.add_page(plantilla)
    with open(salida, "wb") as f:
        w.write(f)
    return total, igv


if __name__ == "__main__":
    datos = json.load(open(sys.argv[1]))
    t, i = construir(datos, sys.argv[2])
    print("total {:.2f}  igv {:.2f}  con igv {:.2f}".format(t, i, t + i))
