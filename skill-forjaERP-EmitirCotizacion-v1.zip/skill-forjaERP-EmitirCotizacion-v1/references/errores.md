# Contrato de errores — skill-forjaERP-EmitirCotizacion-v1

Este es el puente entre la skill y el programa anfitrión de forjaERP. Cuando la
emisión falla, la skill **no solo imprime el error**: deja un archivo JSON de
error en disco y termina. El programa lee ese archivo, muestra al usuario el
`tipo` + `mensaje` en poquísimas palabras, y conserva el resto para diagnóstico.

## Reglas

- Si cualquier paso del flujo falla, no se reintentan pasos: se escribe el
  archivo de error y se termina la ejecución de la skill.
- El archivo de error se escribe **en el mismo directorio** que el PDF de
  salida esperado, con nombre:
  - `error-<numero>.json` si se conoce el correlativo (p. ej. `error-241-2026.json`)
  - `error-sinnumero-<AAAA-MM-DD-HHMMSS>.json` si aún no se conoce
- Si ni siquiera se puede escribir el archivo de error, se reporta el error en
  la salida estándar con el mismo `tipo` y `mensaje`, y se termina.
- El archivo de error NUNCA contiene datos del cliente ni precios: solo
  diagnóstico técnico.

## Formato del archivo

```json
{
  "sistema": "forjaERP",
  "skill": "skill-forjaERP-EmitirCotizacion-v1",
  "tipo": 1,
  "tipo_nombre": "DATOS_INVALIDOS",
  "mensaje": "Datos de la cotizacion incompletos o mal formados.",
  "detalle": "Falta el campo obligatorio 'items' en el JSON de entrada.",
  "archivo_entrada": "C:/ruta/datos.json",
  "salida_esperada": "C:/ruta/Cotizacion 241-2026 - Cliente.pdf",
  "paso": "2",
  "timestamp": "2026-11-12T16:05:00"
}
```

| Campo | Para quién | Qué contiene |
|---|---|---|
| `tipo`, `mensaje` | **Usuario** (el programa muestra solo esto) | Número de tipo + una frase corta |
| `tipo_nombre` | Nosotros | Nombre estable del tipo, para buscar en logs |
| `detalle`, `paso` | Nosotros | Qué falló exactamente y en qué paso del flujo |
| `archivo_entrada`, `salida_esperada` | Nosotros | Rutas para reproducir |
| `timestamp` | Nosotros | Momento del fallo |

## Tipos de error

| Tipo | Nombre | Cuándo | `mensaje` para el usuario |
|---|---|---|---|
| 1 | `DATOS_INVALIDOS` | JSON de entrada malformado o falta un campo obligatorio (`numero`, `fecha`, `cliente.nombre`, `concepto`, `items`) | "Datos de la cotización incompletos o mal formados." |
| 2 | `CORRELATIVO_AGOTADO` | El correlativo pedido está usado y tampoco se pudo determinar el siguiente libre | "Número de cotización en conflicto; revisar correlativos." |
| 3 | `PLANTILLA_AUSENTE` | `assets/plantilla.pdf` no existe o `ESTRUMETAL_PLANTILLA` apunta a un archivo inválido | "Plantilla corporativa no encontrada en la instalación." |
| 4 | `DEPENDENCIA_FALTANTE` | Falta `pypdf` o `reportlab`, o el intérprete de Python | "Faltan componentes técnicos para generar el PDF." |
| 5 | `SALIDA_BLOQUEADA` | `PermissionError` también al intentar escribir como `v2` | "El archivo de salida está bloqueado por otro programa." |
| 6 | `ERROR_SCRIPT` | Excepción no contemplada dentro de `cotizador.py` | "Error interno al generar la cotización." |
| 7 | `ERROR_DESCONOCIDO` | Cualquier otra falla no clasificable | "Error inesperado; se registró el detalle técnico." |

Nota: más de 16 ítems **no** es error — el protocolo de división por familia
(`datos.md` §4) lo resuelve automáticamente. Solo es error si la división misma
falla (entonces `tipo` 6 o 7).

## Dónde buscar nosotros después

1. El `tipo_nombre` es buscable tal cual en logs y en el historial de errores.
2. `paso` (1–5 del flujo de SKILL.md) localiza la etapa: 1 datos, 2 JSON,
   3 script, 4 render, 5 entrega.
3. `detalle` + rutas permiten reproducir con el mismo JSON de entrada.
4. Para `tipo` 6, el traceback completo del script va en el reporte de la
   ejecución (salida estándar), no en el JSON: el JSON queda limpio para el
   programa.
