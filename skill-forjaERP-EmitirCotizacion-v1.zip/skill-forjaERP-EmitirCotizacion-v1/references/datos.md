# Formato del JSON y detalles de la plantilla

Contenido:
1. Campos comunes
2. Modo tabla (`items`)
3. Modo descriptivo (`cuerpo`)
4. División por >16 ítems (automática, modo headless)
5. Condiciones comerciales
6. Sistema de coordenadas y rarezas de la plantilla
7. Bugs conocidos y sus workarounds

---

## 1. Campos comunes

| Campo | Obligatorio | Notas |
|---|---|---|
| `numero` | sí | Correlativo con año: `"184-2026"`. Se estampa como `COTIZACIÓN N° 184-2026`. |
| `fecha` | sí | ISO `"2026-08-21"`. Se imprime en largo: `21 de Agosto de 2026`. Default: hoy. |
| `lugar` | no | Por defecto `"Villa El Salvador"`. |
| `cliente.nombre` | sí | Razón social o persona. Va bajo la etiqueta fija "Señores:". |
| `cliente.direccion` | no | Si va vacío o ausente, la etiqueta "Dirección:" tampoco se imprime. |
| `cliente.atencion` | no | Igual que dirección: vacío ⇒ no se imprime la etiqueta. |
| `concepto` | sí | Título del trabajo en negrita, p. ej. `"FABRICACION DE GANCHERAS"`. |
| `forma_pago` | sí* | `"contado"`, `"credito30"` o `"50_50"`, o `texto_pago` libre. *El script hace `KeyError` si falta; en modo headless usar `"contado"` por defecto. |
| `validez_dias` | sí* | Entero. Default headless: 15. |
| `condiciones_extra` | no | Lista de bullets adicionales (máx. 9). |
| `mostrar_igv` | no | `true` (default) imprime `TOTAL:` + `CON IGV:`; `false` imprime una sola fila `IMPORTE TOTAL:` con el neto. |
| `cierre` | no | Default: "A la espera de su pronta comunicación quedamos a su servicio." |

Los textos se encogen solos hasta caber en su ancho; no hace falta acortarlos
a mano, pero sí revisar el render.

## 2. Modo tabla (`items`)

```json
"items": [
  {
    "cantidad": 500,
    "precio": 10.00,
    "nombre": "GANCHERA GIRATORIA TIPO PULPO",
    "detalle": [
      "Estructura fabricado en alambre de 4 mm y de 2 mm",
      "Pintado al horno electrostático color azul.",
      "Medidas de acuerdo a muestra enviado por el cliente."
    ]
  }
]
```

- `nombre` sale en negrita; cada línea de `detalle` en gris debajo, con corte
  de línea automático.
- El importe por línea se calcula (`cantidad × precio`); no se pasa.
- `igv`: fracción, por defecto `0.18`.
- La altura de fila se reparte entre los ítems: pocas líneas ⇒ filas altas.
- Con más de 16 ítems el script aborta (ver §4 para dividir).

### ⚠️ Bug conocido: el detalle se recorta en silencio

El script calcula `max_lineas = max(1, int((fila_h - 11.0) / (det_size + 1.8)))`
y luego hace `lineas = lineas[:max_lineas]` **sin avisar**.

Consecuencia práctica: con **10+ ítems**, la fila se achica y `max_lineas`
puede quedar en 1, de modo que **una línea entera del detalle desaparece del
PDF sin ninguna advertencia**.

Regla de uso:
- Con 10+ ítems, usar **como máximo 1 línea de detalle** por ítem.
- Revisar siempre el render de cada ítem (paso 4 del flujo).

## 3. Modo descriptivo (`cuerpo`)

Se activa con la clave `cuerpo` en vez de `items`. Cada elemento es un string o
un objeto:

| Clave | Efecto |
|---|---|
| `t` | El texto |
| `b` | `true` ⇒ negrita |
| `u` | `true` ⇒ subrayado |
| `c` | `"navy"` ⇒ azul corporativo |
| `i` | Nivel de sangría (cada nivel, 10 pt) |

Un string vacío `""` deja una línea en blanco. El tamaño de fuente baja solo
hasta que todo entra en la página.

Complementos:

- `resumen`: lista de pares `[etiqueta, valor]` en azul, alineados a la derecha
  del bloque. Ej: `[["Precio x Módulo:", "S/. 1,650.00"]]`.
- `total` y `total_label`: dibujan el recuadro de importe al final.

## 4. División por >16 ítems (automática, modo headless)

El script aborta con `SystemExit` si pasan más de 16 ítems en modo tabla. En
modo headless no se consulta al usuario: se aplica este protocolo y se reporta
el corte en el resultado final.

1. **Dividir por familia de producto** (ítems que comparten tipo: ganchos,
   mallas, barandillas, servicios de corte/pintado, etc.), para que cada parte
   sea coherente y legible.
2. **Numerar las partes** en el `Concepto` y en el nombre del archivo:
   - Concepto: `"FABRICACION DE GANCHERAS (1/2)"` y `"FABRICACION DE GANCHERAS (2/2)"`.
   - Archivo: `"Cotizacion 184-2026 - Cliente (1 de 2).pdf"`.
3. Generar cada parte como cotización independiente (mismo `numero` de serie,
   pero concepto y archivo con su numeración).
4. Reportar en el Output Contract: qué familias van en cada parte y cuántas
   partes se emitieron.

## 5. Condiciones comerciales

Si no se pasa `condiciones`, el script las arma con `forma_pago` +
`validez_dias` + `condiciones_extra`:

- Precios en Nuevos Soles / precios no incluyen IGV / forma de pago / validez
  con la advertencia de variación del acero.

Bullets que aparecen seguido en cotizaciones reales:

- "No incluye ningún accesorio o suministro que no se detalle en la Cotización."
- "No incluye traslado de mercadería."
- "Documento sustentatorio: Factura Electrónica."

Máximo 9 bullets; el espaciado se comprime solo hasta ese tope.

## 6. Coordenadas y rarezas de la plantilla

- La página mide **768 × 1152 px**, pero el MediaBox arranca en **y =
  7.919956**, no en cero. La función `y()` compensa ese offset. Si todo el
  texto aparece corrido unos 8 pt, es porque se cambió la plantilla por una con
  otro MediaBox — hay que actualizar la constante `OFFSET`.
- `CX = [40, 102, 454, 587, 710]` son los bordes de las columnas de la tabla.
  La tabla empieza en `TABLA_Y0 = 468` y no debe pasar de `TABLA_Y_MAX = 900`,
  para dejar aire antes de la barra de CONDICIONES COMERCIALES.
- El script pinta tres rectángulos color `#F7F7F7` sobre zonas donde la
  plantilla original tenía texto fantasma (lugar y fecha, número de documento,
  línea de cierre). En la plantilla incluida esas zonas ya están limpias; si en
  algún render se nota el parche, la solución es quitar el rectángulo de esa
  zona, no repintarlo de otro color.
- Para usar otra plantilla sin editar el script:
  `ESTRUMETAL_PLANTILLA=/ruta/otra.pdf python scripts/cotizador.py datos.json salida.pdf`
  La plantilla alternativa debe tener la página en blanco como **primera** página.
- Datos del pie (RUC 20555485019, dirección, web, teléfono, correo) están
  codificados en el diccionario `PIE` dentro del script. Si cambian, se editan
  ahí (única excepción a la regla de no editar).

## 7. Bugs conocidos y sus workarounds

| Síntoma | Causa | Workaround |
|---|---|---|
| La Ñ o los acentos salen como `Ã‘` / `Ã©` en el PDF | JSON guardado en UTF-8, leído en cp1252 | Escribir y releer el JSON con `encoding='cp1252'` (Hard Rule de SKILL.md) |
| `PermissionError` al escribir el PDF de salida | PDF abierto en un visor (Windows lo bloquea) | Emitir como `<base> v2.pdf` y anotarlo en el reporte |
| `KeyError: 'forma_pago'` | Falta `forma_pago` o `validez_dias` en el JSON | Agregarlos; defaults headless: `"contado"` / 15 |
| `SystemExit` con "más de 16 ítems" | Límite de filas de la tabla por página | Dividir por familia según §4 |
| Una línea del detalle no aparece, sin advertencia | Recorte silencioso del detalle (§2) | Con 10+ ítems, máx. 1 línea de detalle; verificar render |
